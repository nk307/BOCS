# cards-trading-network

A Hyperledger Fabric network to trade cards between permissioned participants/

https://medium.freecodecamp.org/how-to-build-a-blockchain-network-using-hyperledger-fabric-and-composer-e06644ff801d
