import pyqrcode
import sys
import hashlib
from simplecrypt import encrypt, decrypt
from base64 import b64encode, b64decode
from getpass import getpass
string=raw_input()
#result =hashlib.sha256(string.encode())
#print(result.hexdigest())
print("enter the security question:-")
message = raw_input()
cipher = encrypt(string, message)
#encoded_cipher = b64encode(cipher)
#output=b64decode(encoded_cipher)
print(output)
#print(encoded_cipher)
qrkey = pyqrcode.create(encoded_cipher, error='H')
qrkey.png(message+'.png', scale=5)