import pyqrcode
import sys
import hashlib
from simplecrypt import encrypt, decrypt
from base64 import b64encode, b64decode
from getpass import getpass
password = getpass()
message = sys.argv[1]
cipher = encrypt(password, message)
encoded_cipher = b64encode(cipher)
print(encoded_cipher)
qrkey = pyqrcode.create(encoded_cipher, error='H')
qrkey.png(message+'.png', scale=5)