from flask import Flask, render_template, request
from pusher import Pusher
import pyotp
import time
app = Flask(__name__)
pusher = Pusher(app_id='805555', key='4624456b5675dac3c7b1', secret='f09e27c733fb7ecb2642', cluster='ap2',ssl=True)
@app.route('/')
def index():
	return render_template('index.html')
@app.route('/dashboard')
def dashboard():
	return render_template('dashboard.html')

@app.route('/orders', methods=['POST'])
def order():
#print(otp_gen)
#print(	totp.verify(otp_gen))
	#time.sleep(5)
#print(totp.verify(otp_gen))
	data = request.form
	pusher.trigger(u'order', u'place', {
		u'units': data['units']
	})
	return "units logged"
@app.route('/message', methods=['POST'])
def message():
	totp = pyotp.TOTP('base32secret3232')
	otp_gen=totp.now()
	message=otp_gen
	#print(otp_gen)
	data = request.form
	pusher.trigger(u'message', u'send', {
		u'name': data['name'],
		u'message':message
		#u'message': data['message']
	})
	return "Check the dashboard for the TOTP"
@app.route('/customer', methods=['POST'])
def customer():
	data = request.form
	pusher.trigger(u'customer', u'add', {
		u'name': data['name'],
		u'AccNo': data['AccNo'],
		u'Amount': data['Amount'],
		u'IFSC': data['IFSC'],
	})
	return "customer added"
if __name__ == '__main__':
	app.run(debug=True)
