try:
    from qrtools import *
except ImportError:
    from qrtools.qrtools import *
