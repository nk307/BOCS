import qrcode
img = qrcode.make('Some data here')
img = qrcode.make_image()
img.save('/images/1.jpg')