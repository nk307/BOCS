import pyotp
import time
totp = pyotp.TOTP('base32secret3232')
otp_gen=totp.now()
print(otp_gen)
print(totp.verify(otp_gen))
time.sleep(5)
print(totp.verify(otp_gen)) 